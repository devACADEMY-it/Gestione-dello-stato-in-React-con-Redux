import { connect } from 'react-redux';
import Navbar from "./Navbar";
import {toggleTheme} from "./theme/theme-duck";

const mapStateToProps = (state) => ({
  theme: state.theme,
});

const mapDispatchToProps = (dispatch) => ({
  toggleTheme: () => dispatch(toggleTheme())
});

export default connect(mapStateToProps, mapDispatchToProps)(Navbar);
