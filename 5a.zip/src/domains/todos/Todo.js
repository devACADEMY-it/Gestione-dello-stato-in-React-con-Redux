import React from 'react';

function Todo({ data, handleComplete, handleRemove}) {
  const todo = data;

  return (
    <div className="column is-4">
      <div className="card">
        <header className="card-header">
          <p className="card-header-title">{todo.title}</p>
        </header>
        <div className="card-content">
          {todo.description}
          <br/>
          <small>Creato in data {new Date(todo.date).toLocaleDateString()}</small>
        </div>
        <footer className="card-footer">
          { !todo.completed && <a href="#/" className="card-footer-item" onClick={() => handleComplete(todo)}>Completa</a> }
          <a href="#/" className="card-footer-item" onClick={() => handleRemove(todo)}>Elimina</a>
        </footer>
      </div>
    </div>
  )
}

export default Todo;
