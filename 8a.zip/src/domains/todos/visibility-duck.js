
// Costanti
export const VISIBILITY_FILTERS = {
  ALL: 'ALL',
  COMPLETE: 'COMPLETE',
  ACTIVE: 'ACTIVE'
};

export const VISIBILITY_ACTIONS = {
  SET_FILTER: 'visibility/setFilter'
};

// action creator
export const setFilter = (filter) => {
  return {
    type: VISIBILITY_ACTIONS.SET_FILTER,
    filter,
  }
};

export const visibilityReducer = (state = VISIBILITY_FILTERS.ALL, action) => {
  const type = action.type;

  if (type === VISIBILITY_ACTIONS.SET_FILTER) {
    return action.filter
  } else {
    return state;
  }
};
