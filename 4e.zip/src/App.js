import React, { useState } from 'react';
import './App.css';
import Navbar from "./domains/Navbar";
import TodoListContainer from "./domains/todos/TodoListContainer";
import AddTodoContainer from "./domains/todos/AddTodoContainer";
import {Theme} from "./context/theme";

function App() {
  const [theme, setTheme] = useState('light');

  const toggleTheme = () => {
    const newThemeValue = theme === 'dark' ? 'light' : 'dark';
    setTheme(newThemeValue);
  };

  return (
    <Theme.Provider value={{ value: theme, update: toggleTheme }}>
      <Navbar />
      <section className={`section ${theme}`}>
        <TodoListContainer />
        <AddTodoContainer />
      </section>
    </Theme.Provider>
  );
}

export default App;
