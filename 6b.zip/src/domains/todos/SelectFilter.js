import React from 'react';
import {VISIBILITY_FILTERS} from "./visibility-duck";

function SelectFilter({ filter, setFilter }) {
  return (
    <div className="select" style={{ marginBottom: '20px' }}>
      <select value={filter} onChange={(event) => setFilter(event.target.value)}>
        <option value={VISIBILITY_FILTERS.ALL}>ALL</option>
        <option value={VISIBILITY_FILTERS.COMPLETE}>COMPLETE</option>
        <option value={VISIBILITY_FILTERS.ACTIVE}>ACTIVE</option>
      </select>
    </div>
  )
}

export default SelectFilter;
