export const data = [
  {
    id: 1,
    date: new Date(),
    title: 'Spesa',
    description: 'Comprare pane e pasta'
  },
  {
    id: 2,
    date: new Date(),
    title: 'Revisione auto',
    description: 'Scadenza Maggio 2020',
  },
  {
    id: 3,
    date: new Date(),
    title: 'Posta',
    description: 'Pagare bolletta luce',
  },
];
