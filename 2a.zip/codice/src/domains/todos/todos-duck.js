// Costanti
export const TODOS_ACTIONS = {
  ADD: 'todos/add',
  REMOVE: 'todos/remove'
};
