import React from "react";
import TodoListContainer from "./TodoListContainer";
import AddTodoContainer from "./AddTodoContainer";

function TodoSection({ theme }) {
  return (
    <section className={`section ${theme}`}>
      <TodoListContainer />
      <AddTodoContainer />
    </section>
  )
}

export default TodoSection;
