import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';

export const initialState = { todos: [], theme: 'dark' };

ReactDOM.render(<App />, document.getElementById('root'));
