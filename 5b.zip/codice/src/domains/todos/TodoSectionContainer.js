import { connect } from 'react-redux';
import TodoSection from "./TodoSection";
import {setFilter} from "./visibility-duck";

const mapStateToProps = (state) => ({
  theme: state.theme,
});

const mapDispatchToProps = (dispatch) => ({});

export default connect(mapStateToProps, mapDispatchToProps)(TodoSection);
