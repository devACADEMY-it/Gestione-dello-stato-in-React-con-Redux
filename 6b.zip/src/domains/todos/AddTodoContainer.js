import { connect } from 'react-redux';
import {asyncAddTodo} from "./todos-duck";
import AddTodo from "./AddTodo";

const mapStateToProps = (state) => ({
  theme: state.theme,
});

const mapDispatchToProps = (dispatch) => ({
  createTodo: ({ title, description }) => dispatch(asyncAddTodo({ title, description }))
});

export default connect(mapStateToProps, mapDispatchToProps)(AddTodo);
