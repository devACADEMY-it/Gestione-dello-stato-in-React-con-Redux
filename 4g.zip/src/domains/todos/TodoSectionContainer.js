import { connect } from 'react-redux';
import TodoSection from "./TodoSection";

const mapStateToProps = (state) => ({
  theme: state.theme,
});

const mapDispatchToProps = (dispatch) => ({});

export default connect(mapStateToProps, mapDispatchToProps)(TodoSection);
