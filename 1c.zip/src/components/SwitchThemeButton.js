import React, {useContext} from 'react';
import {ThemeContext} from "./context";

function SwitchThemeButton(props) {
  const theme = useContext(ThemeContext);

  const getBackgroundClass = (theme) => {
    return theme === 'dark' ? 'is-white' : 'is-dark';
  };

  return (
    <button
      className={`switch button ${getBackgroundClass(theme.value)}`}
      onClick={theme.update}
    >
      Cambia Tema
    </button>
  )
}

export default SwitchThemeButton;