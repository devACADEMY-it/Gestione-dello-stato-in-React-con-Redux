import React, {useContext} from 'react';
import {Theme} from "../../context/theme";

function SwitchThemeButton() {
  const theme = useContext(Theme);

  const getBackgroundClass = (theme) => {
    return theme === 'dark' ? 'is-white' : 'is-dark';
  };

  return (
    <button
      className={`switch button ${getBackgroundClass(theme.value)}`}
      onClick={theme.update}
    >
      Cambia Tema
    </button>
  )
}

export default SwitchThemeButton;
