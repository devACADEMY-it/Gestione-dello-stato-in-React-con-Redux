import React from 'react';

function SwitchThemeButton({ theme, toggleTheme }) {
  const getBackgroundClass = (theme) => {
    return theme === 'dark' ? 'is-white' : 'is-dark';
  };

  return (
    <button
      className={`switch button ${getBackgroundClass(theme)}`}
      onClick={toggleTheme}
    >
      Cambia Tema
    </button>
  )
}

export default SwitchThemeButton;
