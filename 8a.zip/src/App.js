import React  from 'react';
import './App.css';
import NavbarContainer from "./domains/NavbarContainer";
import TodoSectionContainer from "./domains/todos/TodoSectionContainer";

function App() {
  return (
    <>
      <NavbarContainer />
      <TodoSectionContainer />
    </>
  );
}

export default App;
