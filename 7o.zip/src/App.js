import React from 'react';
import './App.css';
import PeopleList from "./features/people/PeopleList";
import PeopleSearch from "./features/people/PeopleSearch";

function App() {
  return (
    <div className="container is-fluid">
      <div className='section'>
        <PeopleSearch />
        <PeopleList />
      </div>
    </div>
  );
}

export default App;
