import { connect } from 'react-redux';
import TodoList from "./TodoList";
import {completeTodo, removeTodo} from "./todos-duck";
import {VISIBILITY_FILTERS} from "./visibility-duck";

const getFiltered = (todos, filter) => {
  let toRet = todos;
  if (filter === VISIBILITY_FILTERS.ACTIVE) {
    toRet = todos.filter(todo => !todo.completed);
  } else if (filter === VISIBILITY_FILTERS.COMPLETE) {
    toRet = todos.filter(todo => todo.completed);
  }
  return toRet;
};

const mapStateToProps = (state) => ({
  data: getFiltered(state.todos, state.visibility)
});

const mapDispatchToProps = (dispatch) => ({
  handleRemove: (id) => dispatch(removeTodo({ id })),
  handleComplete: (id) => dispatch(completeTodo({ id }))
});

export default connect(mapStateToProps, mapDispatchToProps)(TodoList);
