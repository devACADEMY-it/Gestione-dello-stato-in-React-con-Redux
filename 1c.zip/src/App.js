import React, { useState } from 'react';
import './App.css';
import Navbar from "./components/Navbar";
import TodoList from "./components/TodoList";
import AddTodo from "./components/AddTodo";
import {data} from "./data/todos";
import {ThemeContext} from "./components/context";

function App(props) {
  const [todos, setTodos] = useState(data);
  const [newTodo, setNewTodo] = useState({
    id: data.length + 1,
    title: '',
    description: '',
    date: new Date()
  });
  const [theme, setTheme] = useState('light');

  const toggleTheme = () => {
    const newThemeValue = theme === 'dark' ? 'light' : 'dark';
    setTheme(newThemeValue);
  };

  const handleChange = (event) => {
    event.persist();
    setNewTodo({
      ...newTodo,
      [event.target.name]: event.target.value
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    setTodos([...todos, newTodo]);

    // Reimpostare il nuovo todo
    setNewTodo({
      ...newTodo,
      id: todos.length + 1,
      title: '',
      description: ''
    });
  };

  const handleRemove = (todo) => {
    const newTodos = todos.filter(item => item.id !== todo.id);
    setTodos(newTodos);
  };

  return (
    <ThemeContext.Provider value={{ value: theme, update: toggleTheme }}>
      <Navbar />
      <section className={`section ${theme}`}>
        <TodoList
          data={todos}
          handleRemove={handleRemove}
        />
        <AddTodo
          data={newTodo}
          handleChange={handleChange}
          handleSubmit={handleSubmit}
        />
      </section>
    </ThemeContext.Provider>
  );
}

export default App;