import React, {useState} from 'react';

function AddTodo({ theme, createTodo }) {
  const [newTodo, setNewTodo] = useState({
    title: '',
    description: '',
  });

  const handleChange = (event) => {
    event.persist();
    setNewTodo({
      ...newTodo,
      [event.target.name]: event.target.value
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    createTodo(newTodo)
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="field">
        <label className={`label is-${theme}`}>Titolo</label>
        <div className="control">
          <input
            type="text"
            value={newTodo.title}
            className="input"
            name="title"
            placeholder="es. Fare la spesa"
            onChange={handleChange}
          />
        </div>
      </div>
      <div className="field">
        <label className={`label is-${theme}`}>Descrizione</label>
        <div className="control">
          <input
            type="text"
            value={newTodo.description}
            className="input"
            name="description"
            placeholder="es. comprare pane e uova"
            onChange={handleChange}
          />
        </div>
      </div>
      <button type="submit" className="button is-success">Aggiungi</button>
    </form>
  )
}

export default AddTodo;
