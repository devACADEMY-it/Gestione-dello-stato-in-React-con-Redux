// Costanti
export const TODOS_ACTIONS = {
  ADD: 'todos/add',
  REMOVE: 'todos/remove'
};

// Action creators
export const addTodo = (payload) => {
  return {
    type: TODOS_ACTIONS.ADD,
    payload
  }
};

export const removeTodo = (payload) => {
  return {
    type: TODOS_ACTIONS.REMOVE,
    payload
  }
};

// Reducers
