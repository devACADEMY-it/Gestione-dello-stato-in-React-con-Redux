import { connect } from 'react-redux';
import TodoSection from "./TodoSection";
import {setFilter} from "./visibility-duck";

const mapStateToProps = (state) => ({
  theme: state.theme,
  filter: state.visibility
});

const mapDispatchToProps = (dispatch) => ({
  setFilter: (filter) => dispatch(setFilter(filter))
});

export default connect(mapStateToProps, mapDispatchToProps)(TodoSection);
