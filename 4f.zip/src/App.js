import React  from 'react';
import './App.css';
import Navbar from "./domains/Navbar";
import TodoListContainer from "./domains/todos/TodoListContainer";
import AddTodoContainer from "./domains/todos/AddTodoContainer";

function App() {
  return (
    <>
      <Navbar />
      <section className={`section is-dark`}>
        <TodoListContainer />
        <AddTodoContainer />
      </section>
    </>
  );
}

export default App;
