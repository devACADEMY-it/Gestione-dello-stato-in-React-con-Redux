
// Costanti
import {initialState} from "../rootReducer";

export const TODOS_ACTIONS = {
  ADD: 'todos/add',
  REMOVE: 'todos/remove'
};

// Action creators
export const addTodo = ({ title, description }) => {
  return {
    type: TODOS_ACTIONS.ADD,
    title,
    description,
  }
};

export const removeTodo = ({ id }) => {
  return {
    type: TODOS_ACTIONS.REMOVE,
    id,
  }
};

// Reducers
export const todosReducer = (state = initialState, action) => {
  const type = action.type;
  const todos = state.todos;

  if (type === TODOS_ACTIONS.ADD) {
    const newId = todos.length + 1;
    const newTodo = {
      title: action.title,
      description: action.description,
      date: new Date(),
      id: newId,
    };
    return {
      ...state,
      todos: [ ...todos, newTodo ]
    }
  } else if (type === TODOS_ACTIONS.REMOVE) {
    return {
      ...state,
      todos: todos.filter(todo => todo.id !== action.id),
    }
  } else {
    return state
  }
};
