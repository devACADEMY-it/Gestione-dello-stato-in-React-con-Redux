// Costanti
export const THEME_ACTIONS = {
  TOGGLE: 'theme/toggle',
};

// Action creators
export const toggleTheme = () => {
  return {
    type: THEME_ACTIONS.TOGGLE,
  }
};

// Reducers
export const themeReducer = (state = 'dark', action) => {
  const type = action.type;

  if (type === THEME_ACTIONS.TOGGLE) {
    return state === 'dark' ? 'light' : 'dark'
  } else {
    return state;
  }
};
