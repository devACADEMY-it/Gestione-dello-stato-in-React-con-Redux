import React from 'react';
import Todo from "./Todo";

function TodoList({ data, handleComplete, handleRemove }) {
  return (
    <div className="columns is-multiline">
      {
        data.map(todo =>
          <Todo
            key={todo.id}
            data={todo}
            handleComplete={() => handleComplete(todo.id)}
            handleRemove={() => handleRemove(todo.id)}
          />
        )
      }
    </div>
  )
}

export default TodoList;
