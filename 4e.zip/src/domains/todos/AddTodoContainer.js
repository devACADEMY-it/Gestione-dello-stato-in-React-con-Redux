import { connect } from 'react-redux';
import {addTodo} from "./todos-duck";
import AddTodo from "./AddTodo";

const mapStateToProps = (state) => ({});

const mapDispatchToProps = (dispatch) => ({
  createTodo: ({ title, description }) => dispatch(addTodo({ title, description }))
});

export default connect(mapStateToProps, mapDispatchToProps)(AddTodo);
