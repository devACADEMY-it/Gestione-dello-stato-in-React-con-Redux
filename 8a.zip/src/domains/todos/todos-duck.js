import {data} from "../../data/todos";

// Costanti
export const TODOS_ACTIONS = {
  ADD: 'todos/add',
  COMPLETE: 'todos/complete',
  REMOVE: 'todos/remove'
};

// Action creators
export const asyncAddTodo = ({ title, description }) => {
  return (dispatch) => {
    setTimeout(() => {
      dispatch(addTodo({ title, description }));
    }, 2000);
  }
};

export const addTodo = ({ title, description }) => {
  return {
    type: TODOS_ACTIONS.ADD,
    title,
    description,
  }
};

export const completeTodo = ({ id }) => {
  return {
    type: TODOS_ACTIONS.COMPLETE,
    id,
  }
};

export const removeTodo = ({ id }) => {
  return {
    type: TODOS_ACTIONS.REMOVE,
    id,
  }
};

// Reducers
export const todosReducer = (state = data, action) => {
  const type = action.type;
  const todos = state;

  if (type === TODOS_ACTIONS.ADD) {
    const newId = todos.length + 1;
    const newTodo = {
      title: action.title,
      description: action.description,
      date: new Date(),
      id: newId,
      completed: false,
    };
    return [
      ...state,
      newTodo,
    ]
  } else if (type === TODOS_ACTIONS.REMOVE) {
    const newState = state.filter(todo => todo.id !== action.id);
    return [
      ...newState
    ]
  } else if (type === TODOS_ACTIONS.COMPLETE) {
    const findTodo = state.find(todo => todo.id === action.id);
    if (findTodo) {
      findTodo.completed = true;
    }
    return [
      ...state
    ]
  } else {
    return state
  }
};
