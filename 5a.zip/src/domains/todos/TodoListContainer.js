import { connect } from 'react-redux';
import TodoList from "./TodoList";
import {completeTodo, removeTodo} from "./todos-duck";

const mapStateToProps = (state) => ({
  data: state.todos
});

const mapDispatchToProps = (dispatch) => ({
  handleRemove: (id) => dispatch(removeTodo({ id })),
  handleComplete: (id) => dispatch(completeTodo({ id }))
});

export default connect(mapStateToProps, mapDispatchToProps)(TodoList);
