// Costanti
export const TODOS_ACTIONS = {
  ADD: 'todos/add',
  REMOVE: 'todos/remove'
};

// Action creators
export const addTodo = ({ title, description }) => {
  return {
    type: TODOS_ACTIONS.ADD,
    title,
    description,
  }
};

export const removeTodo = ({ id }) => {
  return {
    type: TODOS_ACTIONS.REMOVE,
    id,
  }
};

// Reducers
export const todosReducer = (state, action) => {
  const type = action.type;

  if (type === TODOS_ACTIONS.ADD) {
    // Logica relativa all'add

  } else if (type === TODOS_ACTIONS.REMOVE) {
    // Logica relativa al remove
  }
};
