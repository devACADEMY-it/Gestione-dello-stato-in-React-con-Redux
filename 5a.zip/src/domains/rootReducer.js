import { combineReducers } from "redux";
import {todosReducer} from "./todos/todos-duck";
import {themeReducer} from "./theme/theme-duck";

export default combineReducers({
  todos: todosReducer,
  theme: themeReducer,
});
