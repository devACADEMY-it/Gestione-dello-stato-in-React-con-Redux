import {initialState} from "../rootReducer";

// Costanti
export const THEME_ACTIONS = {
  TOGGLE: 'theme/toggle',
};

// Action creators
export const toggleTheme = () => {
  return {
    type: THEME_ACTIONS.TOGGLE,
  }
};

// Reducers
export const themeReducer = (state = initialState, action) => {
  const type = action.type;

  if (type === THEME_ACTIONS.TOGGLE) {
    return {
      ...state,
      theme: state.theme === 'dark' ? 'light' : 'dark'
    }
  } else {
    return state;
  }
};
