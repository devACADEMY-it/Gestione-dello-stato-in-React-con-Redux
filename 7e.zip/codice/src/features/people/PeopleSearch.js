import React from 'react';

function PeopleSearch(props) {
  return (
    <input className="input" type="text" placeholder="Luke Skywalker" />
  )
}

export default PeopleSearch;
