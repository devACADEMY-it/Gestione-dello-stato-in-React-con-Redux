import React from 'react';
import './App.css';

function App() {
  return (
    <div className="container is-fluid">
      <div className='section'>

      </div>
    </div>
  );
}

export default App;
