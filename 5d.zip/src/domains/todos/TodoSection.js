import React from "react";
import TodoListContainer from "./TodoListContainer";
import AddTodoContainer from "./AddTodoContainer";
import SelectFilter from "./SelectFilter";

function TodoSection({ theme, filter, setFilter }) {
  return (
    <section className={`section ${theme}`}>
      <SelectFilter filter={filter} setFilter={setFilter} />
      <TodoListContainer />
      <AddTodoContainer />
    </section>
  )
}

export default TodoSection;
