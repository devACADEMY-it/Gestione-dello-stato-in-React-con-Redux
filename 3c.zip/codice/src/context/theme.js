import React from 'react';

export const Theme = React.createContext('light');
