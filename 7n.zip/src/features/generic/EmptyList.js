import React from 'react';

function EmptyList() {
  return (
    <h2 className="subtitle is-4">No results.</h2>
  )
}

export default EmptyList;
