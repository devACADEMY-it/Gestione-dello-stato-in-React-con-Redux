import { combineReducers } from "redux";
import {todosReducer} from "./todos/todos-duck";
import {themeReducer} from "./theme/theme-duck";
import {visibilityReducer} from "./todos/visibility-duck";

export default combineReducers({
  todos: todosReducer,
  visibility: visibilityReducer,
  theme: themeReducer,
});
